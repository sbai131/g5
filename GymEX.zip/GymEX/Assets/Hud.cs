﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Hud : MonoBehaviour {

    public Text InfoPanel;
    public Text AnalysisPanel;
    public Text ThreatAssessmentPanel;
    public Text DiagnosticPanel; 
	
	void Start () {
        AnalysisPanel.text = "INITIALIZING ANALYSIS";
        ThreatAssessmentPanel.text = "INITIALIZING SCAN MODE";
        InfoPanel.text = "CONNECTING";
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
